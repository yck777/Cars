# geojson-download

#### 介绍
批量爬取下载geo.datav.aliyun.com下地图的json文件，存放到本地

#### 软件架构
node + node-xlsx



#### 使用说明
1.  node环境
2.  目录下执行 yarn （或npm install）安装依赖 node-xlsx
3.  目录下 node ./down.js  开始下载
4.  目录下的code.xlsx 是百度提供的全国城镇编码
5.  下载的json文件会存放目录`full_json`和`json`文件夹下



